import 'package:flutter/material.dart';

import 'package:ejemplo_1/classes/carro.dart';
import 'package:ejemplo_1/classes/ordenamiento.dart';
import 'package:ejemplo_1/widgets/navigation_drawer.dart';

class VerTodosScreen extends StatefulWidget {
  List<Carro> carros = [];

  VerTodosScreen({Key? key, required this.carros}) : super(key: key);

  @override
  State<VerTodosScreen> createState() => _VerTodosScreenState();
}

class _VerTodosScreenState extends State<VerTodosScreen> {
  //List<Carro> carros = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const NavigationDrawer(),
      body: CustomScrollView(
        slivers: [
          SliverAppBar.large(
            /* leading: IconButton(
              onPressed: () {},
              icon: Icon(Icons.menu),
            ), */
            title: const Text('Ver Todos'),
            actions: [
              PopupMenuButton(
                itemBuilder: (context) {
                  return [
                    const PopupMenuItem<int>(
                      value: 0,
                      child: Text('Ordenar por Marca'),
                    ),
                    const PopupMenuItem<int>(
                      value: 1,
                      child: Text('Ordenar por Modelo'),
                    ),
                    const PopupMenuItem<int>(
                      value: 2,
                      child: Text('Ordenar por Color'),
                    ),
                    const PopupMenuItem<int>(
                      value: 3,
                      child: Text('Ordenar por ID'),
                    ),
                  ];
                },
                onSelected: (value) {
                  switch (value) {
                    case 0:
                      Ordenamiento.porMarca();
                      break;
                    case 1:
                      Ordenamiento.porModelo();
                      break;
                    case 2:
                      Ordenamiento.porColor();
                      break;
                    case 3:
                      Ordenamiento.porID();
                      break;
                  }
                  setState(() {
                    widget.carros = Ordenamiento.miListaDeCarros;
                  });
                },
              ),
            ],
          ),
          SliverList(
            delegate: SliverChildBuilderDelegate(
              childCount: widget.carros.length,
              (context, index) {
                return ListTile(
                  title: Text(
                      '${widget.carros[index].marca} - ${widget.carros[index].modelo}'),
                  subtitle: Text(
                      '${widget.carros[index].color} - ${widget.carros[index].cantidadDeLlantas.toString()}'),
                  leading: Container(
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                    ),
                    child: CircleAvatar(
                      backgroundColor: Colors.amber,
                      radius: 20,
                      child: Text(
                        '${widget.carros[index].iD}',
                        style: const TextStyle(
                          color: Colors.blue,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
