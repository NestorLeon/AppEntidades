import 'package:ejemplo_1/classes/carro.dart';

class Ordenamiento {
  static final List<Carro> miListaDeCarros = [];

  static void add(Carro carro) {
    miListaDeCarros.add(carro);
  }

  static void poblarLista() {
    miListaDeCarros.add(
      Carro(
        cantidadDeLlantas: 4,
        marca: "GM",
        modelo: "SIERRA",
        color: "AMARILLO",
        iD: 0.1,
      ),
    );
    miListaDeCarros.add(
      Carro(
        cantidadDeLlantas: 4,
        marca: "SUSUKI",
        modelo: "X",
        color: "NEGRO",
        iD: 1.1,
      ),
    );
    miListaDeCarros.add(
      Carro(
        cantidadDeLlantas: 4,
        marca: "MAZDA",
        modelo: "3",
        color: "BLANCO",
        iD: 0.3,
      ),
    );
    miListaDeCarros.add(
      Carro(
        cantidadDeLlantas: 4,
        marca: "TOYOTA",
        modelo: "SUPRA",
        color: "AZUL",
        iD: 4.5,
      ),
    );
    miListaDeCarros.add(Carro(
        cantidadDeLlantas: 4,
        marca: "AUDI",
        modelo: "A4",
        color: "AZUL MARINO",
        iD: 0.5));
    miListaDeCarros.add(
      Carro(
        cantidadDeLlantas: 4,
        marca: "MCLAREN",
        modelo: "T1",
        color: "NEGRO",
        iD: 3.3,
      ),
    );
    miListaDeCarros.add(
      Carro(
        cantidadDeLlantas: 4,
        marca: "HONDA",
        modelo: "CIVIC",
        color: "VERDE",
        iD: 0.2,
      ),
    );
    miListaDeCarros.add(
      Carro(
        cantidadDeLlantas: 4,
        marca: "FORD",
        modelo: "GT40",
        color: "ROJO",
        iD: 0.6,
      ),
    );
    miListaDeCarros.add(
      Carro(
        cantidadDeLlantas: 4,
        marca: "BMW",
        modelo: "M3",
        color: "GRIS",
        iD: 2.1,
      ),
    );
    miListaDeCarros.add(
      Carro(
        cantidadDeLlantas: 4,
        marca: "TESLA",
        modelo: "MODEL3",
        color: "ROJO",
        iD: 1.8,
      ),
    );
    miListaDeCarros.add(
      Carro(
        cantidadDeLlantas: 4,
        marca: "FERRARI",
        modelo: "F40",
        color: "ROJO",
        iD: 1.0,
      ),
    );
  }

  static void porMarca() {
    for (int i = 0; i < miListaDeCarros.length; i++) {
      for (int j = i; j < miListaDeCarros.length; j++) {
        if (miListaDeCarros[i].marca.compareTo(miListaDeCarros[j].marca) > 0) {
          Carro aux = miListaDeCarros[i];
          miListaDeCarros[i] = miListaDeCarros[j];
          miListaDeCarros[j] = aux;
        }
      }
    }
  }

  static void porModelo() {
    for (int i = 0; i < miListaDeCarros.length; i++) {
      for (int j = i; j < miListaDeCarros.length; j++) {
        if (miListaDeCarros[i].modelo.compareTo(miListaDeCarros[j].modelo) >
            0) {
          Carro aux = miListaDeCarros[i];
          miListaDeCarros[i] = miListaDeCarros[j];
          miListaDeCarros[j] = aux;
        }
      }
    }
  }

  static void porColor() {
    for (int i = 0; i < miListaDeCarros.length; i++) {
      for (int j = i; j < miListaDeCarros.length; j++) {
        if (miListaDeCarros[i].color.compareTo(miListaDeCarros[j].color) > 0) {
          Carro aux = miListaDeCarros[i];
          miListaDeCarros[i] = miListaDeCarros[j];
          miListaDeCarros[j] = aux;
        }
      }
    }
  }

  static void porID() {
    for (int i = 0; i < miListaDeCarros.length; i++) {
      for (int j = i; j < miListaDeCarros.length; j++) {
        if (miListaDeCarros[i].iD > miListaDeCarros[j].iD) {
          Carro aux = miListaDeCarros[i];
          miListaDeCarros[i] = miListaDeCarros[j];
          miListaDeCarros[j] = aux;
        }
      }
    }
  }
}
