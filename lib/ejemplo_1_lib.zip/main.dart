import 'package:ejemplo_1/classes/ordenamiento.dart';
import 'package:ejemplo_1/screens/home_screen.dart';
import 'package:flutter/material.dart';

void main() {
  Ordenamiento.poblarLista();

  runApp(
    MaterialApp(
      theme: ThemeData.dark().copyWith(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color.fromARGB(255, 18, 32, 47),
      ),
      debugShowCheckedModeBanner: false,
      home: const HomeScreen(),
    ),
  );

  //final miCarro1 = new Carro(5, "GM", "SIERRA", "NEGRO", 12.22);

  // final miCarro1 = new Carro(
  //     CantidadDeLlantas: 4,
  //     Marca: "GM",
  //     Modelo: "SIERRA",
  //     Color: "NEGRO",
  //     ID: 12.22);

  //Carro[] miArrayDeCarros = Carro[10];

  // ORDENAR POR MARCA
  //print(Ordenamiento.porMarca(miListaDeCarros));

  // ORDENAR POR MODELO
  //print(Ordenamiento.porModelo(miListaDeCarros));

  // ORDENAR POR COLOR
  //print(Ordenamiento.porColor(miListaDeCarros));

  // ORDENAR POR ID
  //print(Ordenamiento.porID(miListaDeCarros));
}
